const next = (x)=>{
    character.style.left = ""+x+"%";
}
