function run() {
    console.log("test");
}
run();